# cluedo
Text based cluedo game.
Link to board drawn with cells: https://docs.google.com/spreadsheets/d/1B-9Ses9AcZ3ltxE0tpl1oqwVlCYyR7dt2G4kMnzmtw0/edit?usp=sharing


Assignment info: https://docs.google.com/document/d/1g7GzhEvfSRJknQUmJ-xhg_cwMSrPV7zMCgkUP6peu1M/edit?usp=sharing


CRC Cards doc: https://docs.google.com/document/d/139jAOB35Nn7jmYv1eyfUvwRYwkhoWUWGBBFxEgHIc9Y/edit?usp=sharing


I've made a start on CRC cards - will revise when the code is further along. I'm not sure if they're right, but I hope they're a good start at least. Feel absolutely free to make any changes/corrections! Have put up a pdf just in case, so we have at least a version to go off. 
