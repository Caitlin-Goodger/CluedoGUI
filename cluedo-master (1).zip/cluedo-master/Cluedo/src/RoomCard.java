/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4597.b7ac3a910 modeling language!*/



// line 31 "model.ump"
// line 75 "model.ump"
public class RoomCard implements Card
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public RoomCard()
  {}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {}

}