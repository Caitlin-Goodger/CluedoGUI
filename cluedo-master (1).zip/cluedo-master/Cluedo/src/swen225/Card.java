package swen225;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4597.b7ac3a910 modeling language!*/

// line 23 "model.ump"
public interface Card
{
	String name = "";
	
	public String getName();
  
}