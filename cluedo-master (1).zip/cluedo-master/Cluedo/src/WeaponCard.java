/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.29.1.4597.b7ac3a910 modeling language!*/



// line 28 "model.ump"
// line 70 "model.ump"
public class WeaponCard implements Card
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //------------------------
  // CONSTRUCTOR
  //------------------------

  public WeaponCard()
  {}

  //------------------------
  // INTERFACE
  //------------------------

  public void delete()
  {}

}